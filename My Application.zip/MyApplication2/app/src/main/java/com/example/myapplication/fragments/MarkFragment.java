package com.example.myapplication.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.View;
import android.widget.Button;

import com.example.myapplication.R;

public class MarkFragment extends Fragment {

    public MarkFragment() {
        super(R.layout.fragment_mark);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Button btnPowrot = view.findViewById(R.id.btnBack);


        btnPowrot.setOnClickListener(v -> {
            getParentFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, new MemoryFragment())

                    .addToBackStack(null)
                    .commit();
        });
    }
}