package com.example.myapplication.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.myapplication.R;

public class MemoryFragment extends Fragment {


        public MemoryFragment() {
            super(R.layout.fragment_memory);
        }

        @Override
        public void onViewCreated(View view, Bundle savedInstanceState) {
            super.onViewCreated(view, savedInstanceState);

            Button ButtonUstawienia = view.findViewById(R.id.ButtonUstawienia);
            Button ButtonLista = view.findViewById(R.id.ButtonListaWyników);
            Button ButtonToLogin = view.findViewById(R.id.ButtonToLogin);

            ButtonLista.setOnClickListener( v -> {
                getParentFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_container, new MarkFragment())
                        .addToBackStack(null)
                        .commit();
            });

            ButtonUstawienia.setOnClickListener(v -> {
                getParentFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_container, new SettingsFragment())
                        .addToBackStack(null)
                        .commit();

            });

            ButtonToLogin.setOnClickListener(v -> {
                getParentFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_container, new LoginFragment())
                        .addToBackStack(null)
                        .commit();
            });
        }



}