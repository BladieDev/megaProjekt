package com.example.myapplication.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.myapplication.R;

public class SettingsFragment extends Fragment{
    public SettingsFragment(){
        super(R.layout.fragment_settings);
    }
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Button Button = view.findViewById(R.id.ButtonPowrot);

        Button.setOnClickListener(v -> {
            getParentFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, new MemoryFragment())
                    .addToBackStack(null)
                    .commit();
        });
    }
}